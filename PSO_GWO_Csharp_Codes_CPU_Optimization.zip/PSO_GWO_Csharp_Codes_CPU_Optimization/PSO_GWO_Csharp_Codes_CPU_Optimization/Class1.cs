﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GWO_PSO
{
    // Define a class for holding the information of each particle
    public class Particle
    {
        public double[] Position { get; set; } // The current position of the particle in the search space
        public double[] Velocity { get; set; } // The current velocity of the particle in the search space
        public double[] BestPosition { get; set; } // The best position so far for the particle
        public double Fitness { get; set; } // The value of the objective function at the current position of the particle
        public double BestFitness { get; set; } // The best value of the objective function so far for the particle

        // The constructor of the class for initializing the properties
        public Particle(int dimension, Random random, Func<double[], double> objectiveFunction)
        {
            Position = new double[dimension];
            Velocity = new double[dimension];
            BestPosition = new double[dimension];
            Fitness = double.MaxValue;
            BestFitness = double.MaxValue;

            // Generate initial position and velocity randomly in the range [-10, 10]
            for (int i = 0; i < dimension; i++)
            {
                Position[i] = random.NextDouble() * 20 - 10;
                Velocity[i] = random.NextDouble() * 20 - 10;
            }

            // Calculate the value of the objective function and update the best position and best value of the objective function
            Fitness = objectiveFunction(Position);
            Position.CopyTo(BestPosition, 0);
            BestFitness = Fitness;
        }

        // A method for updating the velocity and position of the particle using the PSO formulas
        public void Update(Random random, double[] globalBestPosition, double w, double c1, double c2)
        {
            // Update velocity using the formula:
            // v(t+1) = w * v(t) + c1 * r1 * (pbest - x(t)) + c2 * r2 * (gbest - x(t))
            for (int i = 0; i < Velocity.Length; i++)
            {
                double r1 = random.NextDouble();
                double r2 = random.NextDouble();
                Velocity[i] = w * Velocity[i] + c1 * r1 * (BestPosition[i] - Position[i]) + c2 * r2 * (globalBestPosition[i] - Position[i]);
            }

            // Update position using the formula:
            // x(t+1) = x(t) + v(t+1)
            for (int i = 0; i < Position.Length; i++)
            {
                Position[i] += Velocity[i];
            }

            // Calculate the value of the objective function and update the best position and best value of the objective function if improved
            Fitness = objectiveFunction(Position);
            if (Fitness < BestFitness)
            {
                Position.CopyTo(BestPosition, 0);
                BestFitness = Fitness;
            }
        }
    }

    // Define a class for holding the information of each wolf
    public class Wolf
    {
        public double[] Position { get; set; } // The current position of the wolf in the search space
        public double Fitness { get; set; } // The value of the objective function at the current position of the wolf

        // The constructor of the class for initializing the properties
        public Wolf(int dimension, Random random, Func<double[], double> objectiveFunction)
        {
            Position = new double[dimension];
            Fitness = double.MaxValue;

            // Generate initial position randomly in the range [-10, 10]
            for (int i = 0; i < dimension; i++)
            {
                Position[i] = random.NextDouble() * 20 - 10;
            }

            // Calculate the value of the objective function
            Fitness = objectiveFunction(Position);
        }

        // A method for updating the position of the wolf using the GWO formulas
        public void Update(Random random, double[] alphaPosition, double[] betaPosition, double[] deltaPosition, double a)
        {
            // Update position using the formula:
            // x(t+1) = (x_alpha - A1 * D_alpha) + (x_beta - A2 * D_beta) + (x_delta - A3 * D_delta) / 3
            for (int i = 0; i < Position.Length; i++)
            {
                // Generate random parameters A and C in the range [0, 2]
            }
        }
    }
}

